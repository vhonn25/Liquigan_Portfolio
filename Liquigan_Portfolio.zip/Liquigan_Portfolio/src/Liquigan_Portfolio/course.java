package Liquigan_Portfolio;

public class course extends skills {
	String cour = "Course";
	String coursetxt = "COURSE";
	String what = "WHAT IS BSIT-MWA?";
	String why = "WHY BSIT-MWA?";
	
}

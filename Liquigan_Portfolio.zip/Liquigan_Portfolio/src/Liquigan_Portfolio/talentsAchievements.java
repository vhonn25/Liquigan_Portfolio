package Liquigan_Portfolio;

public class talentsAchievements extends course {
	String tal = "Talents & Achievements";
	String talentsAchievements = "Talents/Achievements";
	String talents = "TALENTS";
	String achievements = "ACHIEVEMENTS";
	String lectoring = "Lectoring";
	String studentAchiever = "Student Achiever";
	String editing = "Editing";
	String fjavaproj = "First Java Project";
	String fguiproj = "First Java GUI Project";
	
}

package Liquigan_Portfolio;

public class personalInformation {
	String pers = "Personal Information";
	String age = "19";
	String sex = "Male";
	String bday = "November 25, 2003";
	String address = "Marilag, Quezon City";
	String religion = "Roman Catholic";
	String bckgrnd = "Background";
	String contacts = "Contacts";
	String fb = "John Vhon Liquigan";
	String gmail = "jvliquigan25@gmail.com";
	String number = "09297463951";
	
			
}

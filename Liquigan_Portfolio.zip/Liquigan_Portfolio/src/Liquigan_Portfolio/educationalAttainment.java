package Liquigan_Portfolio;

public class educationalAttainment extends personalInformation {
	String edu = "Educational Attainment";
	String eduAttain = "EDUCATIONAL ATTAINMENT";
	String primary = "PRIMARY";
	String secondary = "SECONDARY";
	String tertiary = "TERTIARY";
	String taes = "T. Alonzo Elementary School";
	String fifteen = "2015-2016";
	String jplshs = "Jose P. Laurel Sr. High School";
	String jca = "JCSGO Christian Academy";
	String nineteen = "2019-2020";
	String twentyone = "2021-2022";
	String nu = "National University";
	String twentytwo = "2022-present";
	
}

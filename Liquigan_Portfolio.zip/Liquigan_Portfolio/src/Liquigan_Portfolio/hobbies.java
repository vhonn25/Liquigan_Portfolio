package Liquigan_Portfolio;

public class hobbies extends educationalAttainment {
	String hob = "Hobbies";
	String hobbiestxt = "HOBBIES";
	String playgames = "PLAYING GAMES";
	String watchmovies = "WATCHING MOVIES";
	String readbooks = "READING BOOKS";
	String cycling = "CYCLING";
	String jogging = "JOGGING";
	
}

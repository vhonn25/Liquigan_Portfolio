package Liquigan_Portfolio;

public class skills extends hobbies {
	String skill = "Skills";
	String skillstxt = "SKILLS";
	String personalskills = "PERSONAL SKILLS";
	String technicalskills = "TECHNICAL SKILLS";
	String document = "DOCUMENTING";
	String collab = "COLLABORATION";
	String adapt = "ADAPTABILITY";
	String critic = "CRITICAL THINKING";
	String premiere = "PREMIERE PRO";
	String photoshop = "PHOTOSHOP";
	String lightroom = "LIGHTROOM";
	String ae = "AFTER EFFECTS";

}
